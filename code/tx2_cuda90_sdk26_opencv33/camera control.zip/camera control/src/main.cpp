//standard include
#include <stdio.h>
#include <string.h>
#include <ctime>
#include <chrono>
#include <thread>
#include <pthread.h>
#include <mutex>

//opencv includes
#include <opencv2/opencv.hpp>
//#include <opencv2/highgui.hpp>

//ZED include
#include <sl/Camera.hpp>


//Time record
#include <time.h>
    
using namespace sl;
using namespace std;

typedef struct image_bufferStruct {
   // unsigned char* data_iml;
    Mat image_left;
   std::mutex mutex_input_imagel;
//	pthread_mutex_t mutex_input_imagel;
   // unsigned char* data_imr;
    Mat image_right;
   std::mutex mutex_input_imager;

	Mat image_depth;
	std::mutex mutex_input_depth;
//	pthread_mutex_t mutex_input_imager;
    //float* data_depth;
    //std::mutex mutex_input_depth;

    int width, height, im_channels;
} image_buffer;

Camera *zed;
image_buffer* buffer;

bool stop_signal;
int count_run = 0;
bool newFrame = false;

cv::Mat slMat2cvMat(Mat& input) {
    // Mapping between MAT_TYPE and CV_TYPE
    int cv_type = -1;
    switch (input.getDataType()) {
        case MAT_TYPE_32F_C1: cv_type = CV_32FC1; break;
        case MAT_TYPE_32F_C2: cv_type = CV_32FC2; break;
        case MAT_TYPE_32F_C3: cv_type = CV_32FC3; break;
        case MAT_TYPE_32F_C4: cv_type = CV_32FC4; break;
        case MAT_TYPE_8U_C1: cv_type = CV_8UC1; break;
        case MAT_TYPE_8U_C2: cv_type = CV_8UC2; break;
        case MAT_TYPE_8U_C3: cv_type = CV_8UC3; break;
        case MAT_TYPE_8U_C4: cv_type = CV_8UC4; break;
        default: break;
    }

    // Since cv::Mat data requires a uchar* pointer, we get the uchar1 pointer from sl::Mat (getPtr<T>())
    // cv::Mat and sl::Mat will share a single memory structure
    return cv::Mat(input.getHeight(), input.getWidth(), cv_type, input.getPtr<sl::uchar1>(MEM_CPU));
}

static void* grab_run(void *arg)
{
    time_t start_time,end_time;	
	start_time = clock();
	cout<<"grap_run start"<<endl;
	RuntimeParameters runtime_parameters;
	runtime_parameters.sensing_mode = SENSING_MODE_STANDARD;
	while(1)
	{
		while(stop_signal == true) //等待主线程将数据存成文件的过程执行完毕
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
		stop_signal = true;
//		cout<<stop_signal<<endl;
//		if(zed->grab(runtime_parameters))
		if(zed->grab(runtime_parameters) == SUCCESS)
		{
			zed->retrieveImage(buffer->image_left,VIEW_LEFT,MEM_CPU,buffer->width,buffer->height);
			zed->retrieveImage(buffer->image_right,VIEW_RIGHT,MEM_CPU,buffer->width,buffer->height);
			zed->retrieveImage(buffer->image_depth,VIEW_DEPTH,MEM_CPU,buffer->width,buffer->height);

			newFrame = true;                //"生产者"通知"消费者"数据已经生产完毕。
			count_run++;
		}
		//else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}		
	}
}

static void * show_run(void *arg)
{
	Resolution image_size = zed->getResolution();
	int new_width = image_size.width/4;
	int new_height = image_size.height/4;
	Mat zed_show(new_width, new_height, MAT_TYPE_8U_C4);
	while(1)
	{
    	if( zed->grab() == SUCCESS)
    	{
	    	zed->retrieveImage(zed_show,VIEW_SIDE_BY_SIDE, MEM_CPU, new_width, new_height);
	     	cv::imshow("side-by-side",cv::Mat((int)zed_show.getHeight(),(int)zed_show.getWidth(),CV_8UC4,zed_show.getPtr<sl::uchar1>(sl::MEM_CPU)))	;
	    	cv::waitKey(5);
		}
	}
}

int main(int argc,char **argv)
{
	stop_signal = false;  // "消费者" 通知"生产者"首先产生数据
	InitParameters init_params;
	zed = new Camera();
	//默认采用1080p/30fps
	init_params.camera_resolution = RESOLUTION_HD1080;
	init_params.camera_fps = 30;
	init_params.depth_mode = DEPTH_MODE_PERFORMANCE;	
	init_params.coordinate_units = UNIT_MILLIMETER;
	if (argc >= 2) // Use in Live Mode
	{
		if( 0 == strncmp(argv[1],"720p",4))
		{
			init_params.camera_resolution = RESOLUTION_HD720;
			init_params.camera_fps = 30;
		}
		else if( 0 == strncmp(argv[1],"1080p",5))
		{
			init_params.camera_resolution = RESOLUTION_HD1080;
			if( 0 == strncmp(argv[2],"30",2))
			{
				init_params.camera_fps = 30;
			}
			else if( 0 == strncmp(argv[2],"15",2))
			{
				init_params.camera_fps = 15;
			}
		}
		else if(0 == strncmp(argv[1],"2.2k",4))
		{
			init_params.camera_resolution = RESOLUTION_HD2K;
			init_params.camera_fps = 15;
		}		
	}
	
	ERROR_CODE err = zed->open(init_params);
	if( err != SUCCESS)
	{
		cout<<"new camera create failed"<<endl;
		exit(-1);
	}
	cout<<"new comera successful"<<endl;
//	sl::Mat image_left,image_right,image_depth;
	char buf_path[200];
	buffer = new image_buffer(); 
//	RuntimeParameters runtime_parameters;
//	runtime_parameters.sensing_mode = SENSING_MODE_STANDARD;

	Resolution image_size = zed->getResolution();
	buffer->width = image_size.width;
	buffer->height = image_size.height;	
	
//	std:: thread grab_thread(grab_run);    //create a grab picture thread

	pthread_t grab_pth , show_pth;
	if( 0 != pthread_create(&grab_pth,NULL,grab_run,NULL))
	{
		cout<<"pthread_create  grab_run failed"<<endl;
		exit(-2);
	}

	if( 0 != pthread_create(&show_pth,NULL,show_run,NULL))
	{
		cout<<"pthread_create show_run failed"<<endl;
		exit(-3);
	}

	cout<<"Press 'q' to exit"<<endl;
	int count = 1;	
//	for(int i = 0;i<50;i++)
	while(1)
	{
		sleep(5);
		if(newFrame)
		{
			newFrame == false;
			time_t start_time,end_time = clock();
	
			buffer->mutex_input_imagel.lock();
			sprintf(buf_path,"/home/nvidia/Desktop/Image/left%d.jpg",count);
			cv::imwrite(buf_path,cv::Mat((int)(buffer->image_left.getHeight()),(int)buffer->image_left.getWidth(),CV_8UC4,buffer->image_left.getPtr<sl::uchar1>(sl::MEM_CPU)));
			//cv::imwrite(buf_path,buffer->image_left_ocv);
			cv::waitKey(5);
			buffer->mutex_input_imagel.unlock();
	
			buffer->mutex_input_imager.lock();
			sprintf(buf_path,"/home/nvidia/Desktop/Image/right%d.jpg",count);
			cv::imwrite(buf_path,cv::Mat((int)(buffer->image_right.getHeight()),(int)buffer->image_right.getWidth(),CV_8UC4,buffer->image_right.getPtr<sl::uchar1>(sl::MEM_CPU)));
			//cv::imwrite(buf_path,buffer->image_right_ocv);
			cv::waitKey(5);
			buffer->mutex_input_imager.unlock();
	
			buffer->mutex_input_depth.lock();
			sprintf(buf_path,"/home/nvidia/Desktop/Image/depth%d.jpg",count);
			cv::imwrite(buf_path,cv::Mat((int)(buffer->image_depth.getHeight()),(int)buffer->image_depth.getWidth(),CV_8UC4,buffer->image_depth.getPtr<sl::uchar1>(sl::MEM_CPU)));
			//cv::imwrite(buf_path,buffer->image_depth_ocv);
			cv::waitKey(5);
			buffer->mutex_input_depth.unlock();
			end_time = clock();

			cout<<"*** "<<count<<"th"<<"picture is writed into file,the write times is: "<<(end_time -start_time)/1000<<"us!"<<endl;
				
			count++;
			stop_signal = false;
		}
		else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
		}
            
	} 
//	grab_thread.join();	
	pthread_join(grab_pth,NULL);
	pthread_join(show_pth,NULL);
	zed->close();
	delete buffer;
	delete zed;
	
	return 0;	
}           
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
